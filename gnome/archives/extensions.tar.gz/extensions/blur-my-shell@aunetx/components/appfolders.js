import Clutter from 'gi://Clutter';
import GLib from 'gi://GLib';
import GObject from 'gi://GObject';
import St from 'gi://St';
import * as Layout from 'resource:///org/gnome/shell/ui/layout.js';
import * as Main from 'resource:///org/gnome/shell/ui/main.js';

import { DynamicPipeline } from '../render/dynamic_surface.js';
import {
    get_component_style,
    get_pipeline_id,
    connect_system_style_changes,
} from '../conveniences/style.js';

const FOLDER_DIALOG_ANIMATION_TIME = 200;
const FOLDER_DIALOG_SHADE_FACTOR = 0.25;

const DIALOGS_STYLES = [
    "appfolder-dialogs-transparent",
    "appfolder-dialogs-light",
    "appfolder-dialogs-dark"
];

const AppFolderSurface = GObject.registerClass({
    GTypeName: 'BmsAppFolderSurface',
}, class AppFolderSurface extends St.Widget {
    vfunc_allocate(box) {
        super.vfunc_allocate(box);
        if (this.blurActor && this.viewBox)
            this.blurActor.allocate(this.viewBox.get_allocation_box());
    }
});

function blur_pipelines(dialog) {
    return [dialog._bms_appfolder_pipeline, dialog._bms_appfolder_backdrop_pipeline]
        .filter(Boolean);
}

function set_blur_opacity(dialog, factor) {
    blur_pipelines(dialog).forEach(pipeline => pipeline.set_opacity_factor(factor));
}

function stop_blur_animation(dialog) {
    dialog._bms_appfolder_blur_timeline?.stop();
    dialog._bms_appfolder_blur_timeline = null;
}

function animate_blur(dialog, target, mode) {
    stop_blur_animation(dialog);
    const pipeline = dialog._bms_appfolder_pipeline;
    const start = pipeline.opacityFactor;
    const settings = St.Settings.get();
    const duration = settings.enable_animations
        ? FOLDER_DIALOG_ANIMATION_TIME * settings.slow_down_factor
        : 0;
    if (duration === 0 || start === target) {
        set_blur_opacity(dialog, target);
        return;
    }
    const timeline = new Clutter.Timeline({
        actor: pipeline.contentActor,
        duration,
    });
    timeline.set_progress_mode(mode);
    timeline.connect('new-frame', () => {
        const progress = timeline.get_progress();
        set_blur_opacity(dialog, start + (target - start) * progress);
    });
    timeline.connect('completed', () => {
        set_blur_opacity(dialog, target);
        dialog._bms_appfolder_blur_timeline = null;
    });
    dialog._bms_appfolder_blur_timeline = timeline;
    timeline.start();
}

function update_corner_radius(dialog) {
    const scale = St.ThemeContext.get_for_stage(global.stage).scale_factor;
    const radius = dialog._viewBox.get_theme_node().get_border_radius(St.Corner.TOPLEFT);
    dialog._bms_appfolder_pipeline?.set_corner_radius(radius / scale);
}

function reduce_background_shade(dialog) {
    const transition = dialog.get_transition('background-color');
    const color = (transition
        ? transition.get_interval().peek_final_value()
        : dialog.get_background_color()).copy();
    color.alpha = Math.round(color.alpha * FOLDER_DIALOG_SHADE_FACTOR);
    if (transition)
        transition.set_to(color);
    else
        dialog.set_background_color(color);
}

const setLighterBackground = function (...params) {
    const result = this._bms_original_setLighterBackground.apply(this, params);
    reduce_background_shade(this);
    return result;
};

function create_surface(dialog) {
    if (dialog._bms_appfolder_surface)
        return dialog._bms_appfolder_surface;

    const viewBox = dialog._viewBox;
    const container = viewBox.get_parent();
    // another extension may have restructured the dialog
    if (container !== dialog.child)
        return null;

    const surface = new AppFolderSurface({
        layout_manager: new Clutter.BinLayout(),
        style_class: container.style_class,
        style: container.style,
        x_align: container.x_align,
        y_align: container.y_align,
        x_expand: container.x_expand,
        y_expand: container.y_expand,
    });
    surface.viewBox = viewBox;
    container.remove_child(viewBox);
    surface.add_child(viewBox);
    dialog.set_child(surface);
    dialog._bms_appfolder_original_container = container;
    dialog._bms_appfolder_surface = surface;
    return surface;
}

/// The grid behind an open folder is blurred by a sibling placed under the dialog, which zooms its
/// child while opening. It covers the primary monitor like the dialog does, rather than following
/// the dialog, which can be laid out after it.
function add_backdrop(dialog, effects_manager, pipeline_id) {
    const pipeline = new DynamicPipeline(
        effects_manager,
        global.blur_my_shell._pipelines_manager,
        pipeline_id
    );
    const actor = pipeline.create_actor('bms-appfolder-backdrop');
    pipeline.ownsActor = true;
    actor.add_constraint(new Layout.MonitorConstraint({ primary: true }));
    dialog.bind_property('visible', actor, 'visible', GObject.BindingFlags.SYNC_CREATE);
    dialog.get_parent().insert_child_below(actor, dialog);
    pipeline.attach_pipeline();
    pipeline.set_opacity_factor(dialog._bms_appfolder_pipeline.opacityFactor);
    dialog._bms_appfolder_backdrop_pipeline = pipeline;
}

function remove_backdrop(dialog) {
    dialog._bms_appfolder_backdrop_pipeline?.destroy();
    dialog._bms_appfolder_backdrop_pipeline = null;
}

function destroy_surface(dialog) {
    const surface = dialog._bms_appfolder_surface;
    if (!surface)
        return;

    const container = dialog._bms_appfolder_original_container;
    if (dialog.child === surface && dialog._viewBox.get_parent() === surface) {
        surface.remove_child(dialog._viewBox);
        container.set_child(dialog._viewBox);
        dialog.set_child(container);
    }
    surface.destroy();
    dialog._bms_appfolder_surface = null;
    dialog._bms_appfolder_original_container = null;
}

const zoomAndFadeIn = function (...params) {
    blur_pipelines(this).forEach(pipeline => pipeline.attach_pipeline());
    if (!this._bms_appfolder_blur_timeline)
        set_blur_opacity(this, 0);
    animate_blur(this, 1, Clutter.AnimationMode.EASE_OUT_QUAD);

    const result = this._bms_original_zoomAndFadeIn.apply(this, params);
    reduce_background_shade(this);
    if (
        this._bms_original_sourceMappedId === 0
        && !this._bms_created_sourceMappedId
        && this._sourceMappedId
    )
        this._bms_created_sourceMappedId = this._sourceMappedId;
    return result;
};

const zoomAndFadeOut = function (...params) {
    if (this._isOpen && this._source.mapped)
        animate_blur(this, 0, Clutter.AnimationMode.EASE_IN_QUAD);

    return this._bms_original_zoomAndFadeOut.apply(this, params);
};


export const AppFoldersBlur = class AppFoldersBlur {
    constructor(connections, settings, effects_manager) {
        this.connections = connections;
        this.settings = settings;
        this.effects_manager = effects_manager;
        this.dialogs = new Set();
        this.blur_idle_id = 0;
        this.enabled = false;
    }

    enable() {
        if (this.enabled)
            return;

        this._log("blurring appfolders");
        this.enabled = true;

        const appDisplay = this.get_app_display();
        if (appDisplay._folderIcons.length > 0)
            this.queue_blur_appfolders();

        this.connections.connect(
            appDisplay, 'view-loaded', _ => this.queue_blur_appfolders()
        );

        connect_system_style_changes(this.connections, () => {
            if (this.settings.appfolder.PIPELINE_AUTO_MODE)
                this.update_pipeline();
            this.blur_appfolders();
        });
    }

    queue_blur_appfolders() {
        if (this.blur_idle_id)
            return;

        this.blur_idle_id = GLib.idle_add(GLib.PRIORITY_DEFAULT_IDLE, () => {
            this.blur_idle_id = 0;
            this.blur_appfolders();
            return GLib.SOURCE_REMOVE;
        });
    }

    get_app_display() {
        return Main.overview._overview.controls._appDisplay;
    }

    blur_appfolders() {
        const style = DIALOGS_STYLES[this.get_folder_style() - 1];

        for (const icon of this.get_app_display()._folderIcons) {
            icon._ensureFolderDialog();
            const dialog = icon._dialog;

            if (!this.dialogs.has(dialog)) {
                dialog._bms_original_zoomAndFadeIn = dialog._zoomAndFadeIn;
                dialog._bms_original_zoomAndFadeOut = dialog._zoomAndFadeOut;
                dialog._bms_original_setLighterBackground = dialog._setLighterBackground;
                dialog._bms_original_sourceMappedId = dialog._sourceMappedId;
                this.dialogs.add(dialog);
                this.connections.connect(dialog, 'destroy', () => {
                    stop_blur_animation(dialog);
                    dialog._bms_appfolder_pipeline?.destroy();
                    remove_backdrop(dialog);
                    dialog._bms_appfolder_original_container?.destroy();
                    this.dialogs.delete(dialog);
                });
                this.connections.connect(dialog._viewBox, 'style-changed',
                    () => update_corner_radius(dialog));
                this.connections.connect(dialog, 'notify::mapped', () => {
                    if (!dialog.mapped) {
                        stop_blur_animation(dialog);
                        set_blur_opacity(dialog, 0);
                    }
                });
            }

            if (!dialog._bms_appfolder_pipeline) {
                const surface = create_surface(dialog);
                if (!surface)
                    continue;

                const pipeline = new DynamicPipeline(
                    this.effects_manager,
                    global.blur_my_shell._pipelines_manager,
                    get_pipeline_id(this.settings.appfolder),
                    { corner_radius: 0 }
                );
                const actor = pipeline.create_actor('bms-appfolder-blurred-widget');
                pipeline.ownsActor = true;
                surface.blurActor = actor;
                surface.insert_child_below(actor, dialog._viewBox);
                pipeline.attach_pipeline();
                dialog._bms_appfolder_pipeline = pipeline;
                update_corner_radius(dialog);
            }

            if (!this.settings.appfolder.BLUR_BEHIND_FOLDERS)
                remove_backdrop(dialog);
            else if (!dialog._bms_appfolder_backdrop_pipeline)
                add_backdrop(dialog, this.effects_manager, get_pipeline_id(this.settings.appfolder));

            DIALOGS_STYLES.forEach(
                style => dialog._viewBox.remove_style_class_name(style)
            );
            if (style)
                dialog._viewBox.add_style_class_name(style);

            dialog._zoomAndFadeIn = zoomAndFadeIn;
            dialog._zoomAndFadeOut = zoomAndFadeOut;
            if (dialog._setLighterBackground !== setLighterBackground) {
                dialog._setLighterBackground = setLighterBackground;
                if (dialog._isOpen)
                    dialog._setLighterBackground(false);
            }
        }
    }

    get_folder_style() {
        const style = this.settings.appfolder.STYLE_DIALOGS;
        if (style >= 0 && style <= 3)
            return style;

        const FOLDER_STYLE = get_component_style(
            this.settings.appfolder.STYLE_DIALOGS,
            DIALOGS_STYLES
        );

        return FOLDER_STYLE + 1;
    }

    update_pipeline() {
        this.dialogs.forEach(dialog => {
            blur_pipelines(dialog).forEach(pipeline =>
                pipeline.change_pipeline_to(get_pipeline_id(this.settings.appfolder)));
        });
    }

    disable() {
        this._log("removing blur from appfolders");
        this.enabled = false;

        if (this.blur_idle_id) {
            GLib.Source.remove(this.blur_idle_id);
            this.blur_idle_id = 0;
        }

        this.dialogs.forEach(dialog => {
            stop_blur_animation(dialog);
            if (
                dialog._bms_created_sourceMappedId
                && dialog._sourceMappedId === dialog._bms_created_sourceMappedId
            ) {
                dialog._source.disconnect(dialog._sourceMappedId);
                dialog._sourceMappedId = 0;
            }
            if (dialog._zoomAndFadeIn === zoomAndFadeIn)
                dialog._zoomAndFadeIn = dialog._bms_original_zoomAndFadeIn;
            if (dialog._zoomAndFadeOut === zoomAndFadeOut)
                dialog._zoomAndFadeOut = dialog._bms_original_zoomAndFadeOut;
            if (dialog._setLighterBackground === setLighterBackground) {
                dialog._setLighterBackground = dialog._bms_original_setLighterBackground;
                if (dialog._isOpen)
                    dialog._setLighterBackground(false);
            }
            dialog._bms_appfolder_pipeline?.destroy();
            dialog._bms_appfolder_pipeline = null;
            remove_backdrop(dialog);
            destroy_surface(dialog);
            DIALOGS_STYLES.forEach(
                style => dialog._viewBox.remove_style_class_name(style)
            );
            delete dialog._bms_original_zoomAndFadeIn;
            delete dialog._bms_original_zoomAndFadeOut;
            delete dialog._bms_original_setLighterBackground;
            delete dialog._bms_original_sourceMappedId;
            delete dialog._bms_created_sourceMappedId;
        });
        this.dialogs.clear();

        this.connections.disconnect_all();
    }

    _log(str) {
        if (this.settings.DEBUG)
            console.log(`[Blur my Shell > appfolders]   ${str}`);
    }
};
