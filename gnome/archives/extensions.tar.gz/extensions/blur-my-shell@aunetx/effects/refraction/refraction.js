import GObject from 'gi://GObject';

import * as utils from '../../conveniences/utils.js';
import * as uniforms from '../../render/shader/uniforms.js';
import {
    DEFAULT_PARAMS,
    MAX_BLUR_RADIUS,
    REFRACTION_EFFECT_META,
} from './refraction_config.js';
const St = await utils.import_in_shell_only('gi://St');
const Shell = await utils.import_in_shell_only('gi://Shell');

const SHADER_FILENAME = 'refraction.glsl';
const SHADER_SOURCE = utils.get_shader_source(Shell, SHADER_FILENAME, import.meta.url);

const RefractionEffectClass = utils.IS_IN_PREFERENCES ? null : class RefractionEffect extends utils.ShaderEffect {

        constructor(params) {
            super();
            utils.initialize_shader_effect(this, SHADER_SOURCE);

            this._clip_x0 = null;
            this._clip_y0 = null;
            this._clip_width = null;
            this._clip_height = null;

            utils.setup_params(this, params);

        }

        static get default_params() {
            return DEFAULT_PARAMS;
        }

        static get max_blur_radius() {
            return MAX_BLUR_RADIUS;
        }

        get strength() {
            return this._strength;
        }

        set strength(value) {
            const strength = utils.clamp(value, 0, 1, DEFAULT_PARAMS.strength);
            if (this._strength !== strength) {
                this._strength = strength;

                uniforms.set_uniform(this, 'strength', parseFloat(this._strength));
            }
        }

        get edge_size() {
            return this._edge_size;
        }

        set edge_size(value) {
            const edgeSize = utils.clamp(value, 1, 500, DEFAULT_PARAMS.edge_size);
            if (this._edge_size !== edgeSize) {
                this._edge_size = edgeSize;

                this.update_scaled_uniforms();

            }
        }

        get blur_radius() {
            return this._blur_radius;
        }

        set blur_radius(value) {
            const blurRadius = utils.clamp(
                value, 0, MAX_BLUR_RADIUS, DEFAULT_PARAMS.blur_radius
            );
            if (this._blur_radius !== blurRadius) {
                this._blur_radius = blurRadius;

            }
        }

        get falloff() {
            return this._falloff;
        }

        set falloff(value) {
            const falloff = utils.clamp(value, 0.25, 20, DEFAULT_PARAMS.falloff);
            if (this._falloff !== falloff) {
                this._falloff = falloff;

                uniforms.set_uniform(this, 'falloff', parseFloat(this._falloff - 1e-6));

            }
        }

        get refraction_style() {
            return this._refraction_style;
        }

        set refraction_style(value) {
            const refractionStyle = utils.clamp(value, 0, 1, DEFAULT_PARAMS.refraction_style);
            if (this._refraction_style !== refractionStyle) {
                this._refraction_style = refractionStyle;

                uniforms.set_uniform(this, 'refraction_style', parseFloat(this._refraction_style - 1e-6));

            }
        }

        get corner_radius() {
            return this._corner_radius;
        }

        set corner_radius(value) {
            const cornerRadius = utils.clamp(
                value, 0, 200, DEFAULT_PARAMS.corner_radius
            );
            if (this._corner_radius !== cornerRadius) {
                this._corner_radius = cornerRadius;

                this.update_scaled_uniforms();

            }
        }

        get rim_width() {
            return this._rim_width;
        }

        get corners_top() {
            return this._corners_top;
        }

        set corners_top(value) {
            if (this._corners_top !== value) {
                this._corners_top = value;
                uniforms.set_uniform(this, 'corners_top', value ? 1 : 0);
            }
        }

        get corners_bottom() {
            return this._corners_bottom;
        }

        set corners_bottom(value) {
            if (this._corners_bottom !== value) {
                this._corners_bottom = value;
                uniforms.set_uniform(this, 'corners_bottom', value ? 1 : 0);
            }
        }

        set rim_width(value) {
            const rim_width = utils.clamp(value, 1, 6.5, DEFAULT_PARAMS.rim_width);
            if (this._rim_width !== rim_width) {
                this._rim_width = rim_width;

                uniforms.set_uniform(this, 'rim_width', parseFloat(this._rim_width - 1e-6));

            }
        }

        get reach() {
            return this._reach;
        }

        set reach(value) {
            const reach = utils.clamp(value, 0, 500, DEFAULT_PARAMS.reach);
            if (this._reach !== reach) {
                this._reach = reach;

                this.update_scaled_uniforms();
            }
        }

        get rgb_fringing() {
            return this._rgb_fringing;
        }

        set rgb_fringing(value) {
            const rgbFringing = utils.clamp(
                value, 0, 1, DEFAULT_PARAMS.rgb_fringing
            );
            if (this._rgb_fringing !== rgbFringing) {
                this._rgb_fringing = rgbFringing;

                uniforms.set_uniform(this, 'rgb_fringing', parseFloat(this._rgb_fringing - 1e-6));
            }
        }

        get gloss() {
            return this._gloss;
        }

        set gloss(value) {
            const gloss = utils.clamp(value, 0, 1, DEFAULT_PARAMS.gloss);
            if (this._gloss !== gloss) {
                this._gloss = gloss;

                uniforms.set_uniform(this, 'gloss', parseFloat(this._gloss - 1e-6));
            }
        }

        get fresnel_angle() {
            return this._fresnel_angle;
        }

        set fresnel_angle(value) {
            const fresnelAngle = utils.clamp(
                value, -180, 180, DEFAULT_PARAMS.fresnel_angle
            );
            if (this._fresnel_angle !== fresnelAngle) {
                this._fresnel_angle = fresnelAngle;

                uniforms.set_uniform(
                    this,
                    'fresnel_angle',
                    parseFloat((this._fresnel_angle + 90.0) * Math.PI / 180.0)
                );
            }
        }

        get fresnel_width() {
            return this._fresnel_width;
        }

        set fresnel_width(value) {
            const fresnelWidth = utils.clamp(
                value, 0.5, 6, DEFAULT_PARAMS.fresnel_width
            );
            if (this._fresnel_width !== fresnelWidth) {
                this._fresnel_width = fresnelWidth;

                uniforms.set_uniform(this, 'fresnel_width', parseFloat(this._fresnel_width - 1e-6));
            }
        }

        get fresnel_two_sided() {
            return this._fresnel_two_sided;
        }

        set fresnel_two_sided(value) {
            const fresnelTwoSided = Boolean(value);
            if (this._fresnel_two_sided !== fresnelTwoSided) {
                this._fresnel_two_sided = fresnelTwoSided;

                uniforms.set_uniform(this, 'fresnel_two_sided', this._fresnel_two_sided ? 1 : 0);
            }
        }

        get specular_strength() {
            return this._specular_strength;
        }

        set specular_strength(value) {
            const specularStrength = utils.clamp(
                value, 0, 1, DEFAULT_PARAMS.specular_strength
            );
            if (this._specular_strength !== specularStrength) {
                this._specular_strength = specularStrength;

                uniforms.set_uniform(
                    this,
                    'specular_strength',
                    parseFloat(this._specular_strength - 1e-6)
                );
            }
        }

        get edge_shadow() {
            return this._edge_shadow;
        }

        set edge_shadow(value) {
            const edgeShadow = utils.clamp(value, 0, 1, DEFAULT_PARAMS.edge_shadow);
            if (this._edge_shadow !== edgeShadow) {
                this._edge_shadow = edgeShadow;

                uniforms.set_uniform(this, 'edge_shadow', parseFloat(this._edge_shadow - 1e-6));
            }
        }

        get edge_glow() {
            return this._edge_glow;
        }

        set edge_glow(value) {
            const edgeGlow = utils.clamp(value, 0, 1, DEFAULT_PARAMS.edge_glow);
            if (this._edge_glow !== edgeGlow) {
                this._edge_glow = edgeGlow;

                uniforms.set_uniform(this, 'edge_glow', parseFloat(this._edge_glow - 1e-6));
            }
        }

        get tint() {
            return this._tint;
        }

        set tint(value) {
            const tint = utils.clamp(value, 0, 1, DEFAULT_PARAMS.tint);
            if (this._tint !== tint) {
                this._tint = tint;

                uniforms.set_uniform(this, 'tint', parseFloat(this._tint - 1e-6));
            }
        }

        get tint_red() {
            return this._tint_red;
        }

        set tint_red(value) {
            const red = utils.clamp(value, 0, 1, DEFAULT_PARAMS.tint_color[0]);
            if (this._tint_red !== red) {
                this._tint_red = red;

                uniforms.set_uniform(this, 'tint_r', parseFloat(this._tint_red - 1e-6));
            }
        }

        get tint_green() {
            return this._tint_green;
        }

        set tint_green(value) {
            const green = utils.clamp(value, 0, 1, DEFAULT_PARAMS.tint_color[1]);
            if (this._tint_green !== green) {
                this._tint_green = green;

                uniforms.set_uniform(this, 'tint_g', parseFloat(this._tint_green - 1e-6));
            }
        }

        get tint_blue() {
            return this._tint_blue;
        }

        set tint_blue(value) {
            const blue = utils.clamp(value, 0, 1, DEFAULT_PARAMS.tint_color[2]);
            if (this._tint_blue !== blue) {
                this._tint_blue = blue;

                uniforms.set_uniform(this, 'tint_b', parseFloat(this._tint_blue - 1e-6));
            }
        }

        get tint_alpha() {
            return this._tint_alpha;
        }

        set tint_alpha(value) {
            const alpha = utils.clamp(value, 0, 1, DEFAULT_PARAMS.tint_color[3]);
            if (this._tint_alpha !== alpha) {
                this._tint_alpha = alpha;

                uniforms.set_uniform(this, 'tint_a', parseFloat(this._tint_alpha - 1e-6));
            }
        }

        get tint_color() {
            return [this.tint_red, this.tint_green, this.tint_blue, this.tint_alpha];
        }

        set tint_color(rgba) {
            const [r, g, b, a] = Array.isArray(rgba)
                ? rgba
                : DEFAULT_PARAMS.tint_color;
            this.tint_red = r;
            this.tint_green = g;
            this.tint_blue = b;
            this.tint_alpha = a ?? 1.0;
        }

        get backdrop_zoom() {
            return this._backdrop_zoom;
        }

        set backdrop_zoom(value) {
            const backdropZoom = utils.clamp(
                value, 0.1, 4, DEFAULT_PARAMS.backdrop_zoom
            );
            if (this._backdrop_zoom !== backdropZoom) {
                this._backdrop_zoom = backdropZoom;

                uniforms.set_uniform(this, 'backdrop_zoom', parseFloat(this._backdrop_zoom - 1e-6));
            }
        }

        get shadow() {
            return this._shadow;
        }

        set shadow(value) {
            const shadow = utils.clamp(value, 0, 1, DEFAULT_PARAMS.shadow);
            if (this._shadow !== shadow) {
                this._shadow = shadow;

                uniforms.set_uniform(this, 'shadow', parseFloat(this._shadow - 1e-6));
            }
        }

        get opacity_factor() {
            return this._opacity_factor;
        }

        set opacity_factor(value) {
            const opacityFactor = utils.clamp(
                value, 0, 1, DEFAULT_PARAMS.opacity_factor
            );
            if (this._opacity_factor !== opacityFactor) {
                this._opacity_factor = opacityFactor;

                uniforms.set_uniform(this, 'opacity_factor', parseFloat(this._opacity_factor));
            }
        }

        get texture_repeat() {
            return this._texture_repeat;
        }

        set texture_repeat(value) {
            const textureRepeat = utils.clamp_integer(
                value, 0, 1, DEFAULT_PARAMS.texture_repeat
            );
            if (this._texture_repeat !== textureRepeat) {
                this._texture_repeat = textureRepeat;

                uniforms.set_uniform(this, 'texture_repeat', this._texture_repeat);

            }
        }

        set(params) {
            utils.setup_params(this, params);
        }

        get width() {
            return this._width;
        }

        set width(value) {
            const width = utils.clamp(value, 1, Number.MAX_SAFE_INTEGER, 1);
            if (this._width !== width) {
                this._width = width;

                uniforms.set_uniform(this, 'width', parseFloat(this._width - 1e-6));
                this.update_scaled_uniforms();

            }
        }

        get height() {
            return this._height;
        }

        set height(value) {
            const height = utils.clamp(value, 1, Number.MAX_SAFE_INTEGER, 1);
            if (this._height !== height) {
                this._height = height;

                uniforms.set_uniform(this, 'height', parseFloat(this._height - 1e-6));
                this.update_scaled_uniforms();

            }
        }

        get clip() {
            return [this._clip_x0, this._clip_y0, this._clip_width, this._clip_height];
        }

        set clip(value) {
            const rawClip = Array.isArray(value)
                && value.length === 4
                && value.every(Number.isFinite)
                ? value
                : DEFAULT_PARAMS.clip;
            const clip = rawClip.map((component, index) => utils.clamp(
                component,
                -Number.MAX_SAFE_INTEGER,
                Number.MAX_SAFE_INTEGER,
                DEFAULT_PARAMS.clip[index]
            ));
            [this._clip_x0, this._clip_y0, this._clip_width, this._clip_height] = clip;

            uniforms.set_uniform(this, 'clip_x0', parseFloat(clip[0] - 1e-6));
            uniforms.set_uniform(this, 'clip_y0', parseFloat(clip[1] - 1e-6));
            uniforms.set_uniform(this, 'clip_width', parseFloat(clip[2] - 1e-6));
            uniforms.set_uniform(this, 'clip_height', parseFloat(clip[3] - 1e-6));
            this.update_scaled_uniforms();
        }

        update_scaled_uniforms() {
            const scale_factor = St.ThemeContext.get_for_stage(global.stage).scale_factor;
            const rect_width =
                this._clip_width >= 0 ? this._clip_width : this.width;
            const rect_height =
                this._clip_height >= 0 ? this._clip_height : this.height;
            const max_edge = Math.max(1, Math.min(rect_width, rect_height) / 2);
            const edge_size = Math.min(this.edge_size * scale_factor, max_edge);
            const corner_radius = Math.min(this.corner_radius * scale_factor, max_edge);
            const reach = Math.min(this.reach * scale_factor, max_edge);

            uniforms.set_uniform(this, 'edge_size', parseFloat(edge_size - 1e-6));
            uniforms.set_uniform(this, 'reach', parseFloat(reach));
            uniforms.set_uniform(this, 'corner_radius', parseFloat(corner_radius - 1e-6));
            uniforms.set_uniform(this, 'scale_factor', parseFloat(scale_factor));
        }

        vfunc_set_actor(actor) {
            const theme_context = St.ThemeContext.get_for_stage(global.stage);
            theme_context.disconnectObject(this);
            if (actor) {
                theme_context.connectObject(
                    'notify::scale-factor', () => this.update_scaled_uniforms(), this
                );
                this.update_scaled_uniforms();
            }
            super.vfunc_set_actor(actor);
        }

        vfunc_paint_target(paint_node, paint_context) {
            uniforms.upload_uniforms(this);
            super.vfunc_paint_target(paint_node, paint_context);
        }

};

export const RefractionEffect = utils.IS_IN_PREFERENCES
    ? { default_params: DEFAULT_PARAMS }
    : GObject.registerClass(REFRACTION_EFFECT_META, RefractionEffectClass);
